package com.example.cai.kh5;

/**
 * Created by Administrator on 2016/1/4.
 */
public class Detail {
    private int BigImage;
    private String function;

}
